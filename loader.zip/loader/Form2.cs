﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loader
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process[] processes = Process.GetProcessesByName("csgo");

            if (processes.Length == 0)
            {
                Form3 form3 = new Form3();
                form3.Show();
                this.Hide(); 
            }
            else
            {
                Form4 form4 = new Form4();
                form4.Show();
                this.Hide(); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.BackColor = Color.FromArgb(26, 26, 26);
            label1.ForeColor = Color.FromArgb(99, 152, 22);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.BackColor = Color.FromArgb(26, 26, 26);
            label2.ForeColor = Color.FromArgb(99, 152, 22);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            label3.BackColor = Color.FromArgb(26, 26, 26);
            label3.ForeColor = Color.FromArgb(99, 152, 22);
        }

        private void label4_Click(object sender, EventArgs e)
        {
            label4.BackColor = Color.FromArgb(26, 26, 26);
            label4.ForeColor = Color.FromArgb(99, 152, 22);
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}
